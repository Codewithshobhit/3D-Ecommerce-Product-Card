document.getElementById('canvas3d').addEventListener('click', () => {
  document.getElementById('rotate').classList.toggle('bg-indigo-600');
  document.getElementById('rotate').classList.toggle('bg-lime-500');
});