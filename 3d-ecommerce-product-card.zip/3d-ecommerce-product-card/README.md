# 3D Ecommerce Product Card

A Pen created on CodePen.io. Original URL: [https://codepen.io/Codewithshobhit/pen/NWJqgjv](https://codepen.io/Codewithshobhit/pen/NWJqgjv).

3D experience made with Spline.



Credits: 3D shoe made by Przemek Gesicki, downloaded on Sketchfab.